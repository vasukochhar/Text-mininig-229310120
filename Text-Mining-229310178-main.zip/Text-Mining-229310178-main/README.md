Text-Mining Project **Sentiment Analysis**

Jatinpreet Singh - 229310178 - 7th A
